function diasFestivos() {
        this.diasFestivos = new Array();
        var nombreDiasFestivos = new Array();
        this.diasFestivos[0] = "1/6/2013";
        nombreDiasFestivos[0]="dia de reyes";
        this.diasFestivos[1] = "12/6/2012";
        nombreDiasFestivos[1]="dia de reyes";
        this.diasFestivos[2] = "12/28/2012";
        nombreDiasFestivos[2]="dia de los santos inocentes";
        this.diasFestivos[3] = "12/25/2012";
        nombreDiasFestivos[3]="dia de navidad";
           
           
        this.current = 0;

        this.siguiente = function () {
          this.current++;
          if (this.current >= this.dias.length) this.current = 0;
          
          for (var i = 0; i < this.dias.length; i++) this.dias[i].className = 'dia hidden';
          this.dias[this.current].className = 'dia';
        };

        this.anterior = function () {
          this.current--;
          if (this.current < 0) this.current = this.dias.length - 1;
          
          for (var i = 0; i < this.dias.length; i++) this.dias[i].className = 'dia hidden';
          this.dias[this.current].className = 'dia';
        };


        function calcularDiasFestivos(dia){
          
          var festivo  = new Date(dia);
          var hoy = new Date();
          var anio = hoy.getFullYear() - festivo.getFullYear();
          // Determine the number of mes.
          var unDiaEnMilisegundos = 1000*60*60*24;
          var quedan = parseInt((festivo - hoy) / unDiaEnMilisegundos);
        
          var mes = (anio * 12) + (hoy.getMonth() - festivo.getMonth());
          
          if (festivo < hoy){
           // alert("hola");
           }
          else{
             document.write("<div id='dia"+i+"' class=\"dia hidden\" style=''>Faltan <h2>"+ quedan + "</h2> para el día de " + nombreDiasFestivos[i] + "</div>");
          }
          // write date in navigator
         

        }
         
        for (var i = 0; i < this.diasFestivos.length; i++) {
         
          calcularDiasFestivos(this.diasFestivos[i]);


        };

        this.dias = document.querySelectorAll('.dia');
        this.dias[0].className = 'dia';

        var self = this;
        document.getElementById('siguiente').onclick = function () {
          self.siguiente();
        }
        document.getElementById('anterior').onclick = function () {
          self.anterior();
        }

        // for (var i = 0; i < dias.length; i++) {
        //   dias[i].onclick = function(e){
        //     this.className = 'dia hidden';
        //     if (this.nextSibling.className) this.nextSibling.className = 'dia';
        //     else this.parentNode.querySelector('.dia.hidden').className = 'dia';
        //   }
        // };

        document.getElementById('contenedor').style.backgroundColor='purple';
      }

      var t = new diasFestivos();
      