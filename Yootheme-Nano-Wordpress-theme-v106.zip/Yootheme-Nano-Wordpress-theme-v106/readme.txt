Hi,

These are Yootheme wordpress templates I downloaded on nov 18 2011.

Included in this archive is;
 
1) The wordpress template, 
2) The wordpress template + wordpress itself + demopages and posts (really usefull if you want to see how everything works)
3) The image sources

and;

4) Warp BuddyPress Plugin, Updated on 25 October 2011, Adds BuddyPress 1.5 support to Warp Themes. Version: 0.4 Beta

5: Widgekit things, 4 archives;

Widgetkit
Updated on 18 November 2011
WordPress Plugin
Version: 1.0 BETA 17

Widgetkit Bonus Styles
Updated on 01 July 2011
Bonus Widget Styles

Widgetkit Image Source Files
Updated on 01 July 2011
Fireworks CS4/CS5 source files

Widgetkit Bonus Style Image Source Files
Updated on 01 July 2011
Fireworks CS4/CS5 source files

Wish you luck. And rememeber, if you like these themes it's better to buy them. They are not so expensive.
