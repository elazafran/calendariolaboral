<?php echo $module->content; ?>

<p>
    <a class="button-more" href="<?php echo $module->params['url']; ?>" target="_blank"><?php _e('Read feed'); ?></a>
</p>