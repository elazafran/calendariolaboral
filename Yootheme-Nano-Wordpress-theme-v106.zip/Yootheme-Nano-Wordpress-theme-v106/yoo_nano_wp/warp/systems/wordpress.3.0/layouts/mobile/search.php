<form action="<?php echo home_url('/'); ?>" method="post" role="search">
    <input type="text" value="" name="s" placeholder="<?php _e('search...', 'warp'); ?>" />
</form>