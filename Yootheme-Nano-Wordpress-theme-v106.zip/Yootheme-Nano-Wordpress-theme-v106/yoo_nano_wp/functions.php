<?php
/**
* @package   Nano
* @author    YOOtheme http://www.yootheme.com
* @copyright Copyright (C) YOOtheme GmbH
* @license   YOOtheme Proprietary Use License (http://www.yootheme.com/license)
*/

// load config    
require_once(dirname(__FILE__).'/config.php');